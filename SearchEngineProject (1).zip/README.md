# Fast Keyword Search Engine for Indian-Language Text (Java)

DSA-3 project implementation matching the PPT: "Fast Keyword-Based Search
Engine for Indian-Language Wikipedia Text using Efficient Indexing."

## What it does

- **TextPreprocessor** — Unicode-aware tokenizer (works on Latin, Devanagari,
  Telugu, Tamil, Bengali, etc.), NFC normalization, stop-word removal.
- **InvertedIndex** — hash-based inverted index (`HashMap<term, HashMap<docId, frequency>>`).
  Built once over the corpus; every query after that is O(1)-average hash
  lookups instead of re-scanning documents.
- **SearchEngine** — single- and multi-keyword search, ranked by combined
  term frequency, with `ANY` (OR) / `ALL` (AND) match modes. Also includes a
  naive `linearScanSearch` so you can measure the speedup the index gives you.
- **Main** — console menu: search (indexed), search (linear scan), a
  benchmark comparing the two, and index stats.
- **data/corpus/** — 10 short sample "articles" in English, Hindi, Telugu,
  Tamil and Bengali, so multi-language search works out of the box. Swap
  these `.txt` files for your real Wikipedia-dump extracts later — the code
  doesn't change, just the files in this folder.

## Project structure

```
SearchEngineProject/
├── src/
│   ├── Main.java
│   ├── Document.java
│   ├── TextPreprocessor.java
│   ├── InvertedIndex.java
│   └── SearchEngine.java
├── data/
│   └── corpus/          (sample .txt documents)
└── README.md
```

## Requirements

- **JDK 11+** (not just a JRE). Check with:
  ```
  java -version
  javac -version
  ```
  If `javac` isn't found, install a JDK (e.g. Temurin/OpenJDK) — on Windows/macOS
  the easiest route is the **"Extension Pack for Java"** in VS Code, which can
  download one for you the first time you open a `.java` file.

## Running in VS Code

**Easiest — Extension Pack for Java:**
1. Install the **"Extension Pack for Java"** (Microsoft) from the Extensions tab.
2. Open the `SearchEngineProject` folder in VS Code (`File > Open Folder…`).
3. Open `src/Main.java`.
4. Click **Run** above the `main` method (or press `F5`).
   - VS Code compiles and runs it for you, and opens an integrated terminal
     you can type into.

**No extension — plain terminal (works even without the extension):**
```bash
cd SearchEngineProject
javac -d out -encoding UTF-8 src/*.java
java -cp out Main
```
Run these from the `SearchEngineProject` folder itself (not from inside
`src`) — the program looks for `data/corpus` relative to where you launch it.

## Using it

You'll see a menu:
```
1. Search (indexed - fast)
2. Search (linear scan - baseline, for comparison)
3. Benchmark: indexed vs linear scan
4. Show index stats
0. Exit
```
Try option 1, then type e.g. `river ganga` and choose `any` or `all`. Try the
same query with a Hindi word like `गंगा`, or Telugu `చార్మినార్`, to see the
Unicode handling in action. Option 3 prints timing numbers you can quote
directly in your "Results" slide.

## Extending it toward the full project

- Point `loadCorpus` at a folder of real article dumps instead of the demo
  files (same `.txt`-per-document format).
- Swap TF ranking for **TF-IDF** or **BM25** (Future Scope slide) by adding
  document-frequency counts to `InvertedIndex` and a new scoring method in
  `SearchEngine`.
- Add phrase search / boolean `AND`/`OR`/`NOT` operators by extending the
  query parser in `Main.runSearch`.
- Add a `Trie` class for prefix search, as mentioned in the Literature Survey.
