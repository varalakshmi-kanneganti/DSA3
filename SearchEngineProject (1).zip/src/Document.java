/**
 * A single "document" (article) in the corpus.
 * Stands in for one Wikipedia article.
 */
public class Document {
    private final int id;
    private final String title;
    private final String content;

    public Document(int id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }
}
