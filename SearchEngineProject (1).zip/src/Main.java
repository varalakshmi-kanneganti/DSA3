import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

/**
 * DSA-3 Project: Fast Keyword-Based Search Engine for Indian-Language
 * Wikipedia Text using Efficient Indexing.
 *
 * Demonstrates: Unicode-aware tokenization, a hash-based inverted index,
 * single/multi-keyword search ranked by term frequency, and a benchmark
 * against a naive linear scan.
 */
public class Main {

    public static void main(String[] args) throws IOException {
        System.out.println("=========================================================");
        System.out.println(" Fast Keyword Search Engine - Indian-Language Wikipedia   ");
        System.out.println(" (Inverted Index + Hashing demo, DSA-3 Project)           ");
        System.out.println("=========================================================\n");

        List<Document> corpus = loadCorpus("data/corpus");
        System.out.println("Loaded " + corpus.size() + " documents from data/corpus\n");

        InvertedIndex index = new InvertedIndex();
        long buildStart = System.nanoTime();
        index.build(corpus);
        long buildEnd = System.nanoTime();
        System.out.printf("Index built: %d unique terms across %d documents (%.3f ms)%n%n",
                index.vocabularySize(), index.documentCount(), (buildEnd - buildStart) / 1_000_000.0);

        SearchEngine engine = new SearchEngine(index);
        Scanner sc = new Scanner(System.in, "UTF-8");

        while (true) {
            System.out.println("---------------------------------------------------------");
            System.out.println("1. Search (indexed - fast)");
            System.out.println("2. Search (linear scan - baseline, for comparison)");
            System.out.println("3. Benchmark: indexed vs linear scan");
            System.out.println("4. Show index stats");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");
            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1":
                    runSearch(sc, engine, false);
                    break;
                case "2":
                    runSearch(sc, engine, true);
                    break;
                case "3":
                    benchmark(engine, corpus);
                    break;
                case "4":
                    System.out.println("Documents: " + index.documentCount());
                    System.out.println("Vocabulary size: " + index.vocabularySize());
                    break;
                case "0":
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option.\n");
            }
        }
    }

    private static void runSearch(Scanner sc, SearchEngine engine, boolean linear) {
        System.out.print("Enter keyword(s), space-separated (any language): ");
        String line = sc.nextLine().trim();
        if (line.isEmpty()) return;
        List<String> keywords = Arrays.asList(line.split("\\s+"));

        System.out.print("Match ANY keyword or ALL keywords? (any/all) [any]: ");
        String modeInput = sc.nextLine().trim();
        String mode = modeInput.equalsIgnoreCase("all") ? "AND" : "OR";

        long start = System.nanoTime();
        List<SearchEngine.Result> results = linear
                ? engine.linearScanSearch(keywords, mode)
                : engine.search(keywords, mode);
        long end = System.nanoTime();

        System.out.printf("%n%s search took %.4f ms -> %d result(s)%n%n",
                linear ? "Linear-scan" : "Indexed", (end - start) / 1_000_000.0, results.size());

        int rank = 1;
        for (SearchEngine.Result r : results) {
            System.out.printf("%d. [score=%d] %s (doc #%d)%n",
                    rank++, r.score, r.document.getTitle(), r.document.getId());
        }
        System.out.println();
    }

    private static void benchmark(SearchEngine engine, List<Document> corpus) {
        List<String> keywords = Arrays.asList("india", "river");
        int rounds = 3000;

        long t0 = System.nanoTime();
        for (int i = 0; i < rounds; i++) engine.search(keywords, "OR");
        long t1 = System.nanoTime();
        for (int i = 0; i < rounds; i++) engine.linearScanSearch(keywords, "OR");
        long t2 = System.nanoTime();

        double indexedMs = (t1 - t0) / 1_000_000.0;
        double linearMs = (t2 - t1) / 1_000_000.0;

        System.out.printf("%nOver %d repeated queries on %d documents:%n", rounds, corpus.size());
        System.out.printf("  Indexed search    : %8.2f ms total  (%.5f ms/query)%n", indexedMs, indexedMs / rounds);
        System.out.printf("  Linear-scan search: %8.2f ms total  (%.5f ms/query)%n", linearMs, linearMs / rounds);
        System.out.printf("  Speedup: %.2fx%n%n", linearMs / indexedMs);
        System.out.println("(With this small demo corpus the gap is modest; it grows");
        System.out.println(" sharply as the corpus scales toward real Wikipedia sizes,");
        System.out.println(" which is the whole point of building an index.)\n");
    }

    private static List<Document> loadCorpus(String folderPath) throws IOException {
        File folder = new File(folderPath);
        File[] files = folder.listFiles((d, name) -> name.endsWith(".txt"));
        if (files == null) {
            throw new FileNotFoundException(
                    "Corpus folder not found: " + folder.getAbsolutePath() +
                    "  (run the program from the project's root folder)");
        }
        Arrays.sort(files, Comparator.comparing(File::getName));

        List<Document> docs = new ArrayList<>();
        int id = 1;
        for (File f : files) {
            String content = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
            String title = f.getName().replace(".txt", "").replace("_", " ");
            docs.add(new Document(id++, title, content));
        }
        return docs;
    }
}
