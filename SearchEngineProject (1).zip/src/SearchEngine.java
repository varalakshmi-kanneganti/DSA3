import java.util.*;

/**
 * Answers single- and multi-keyword queries two ways:
 *   - search()            : fast, uses the InvertedIndex (hash lookups)
 *   - linearScanSearch()  : naive baseline, scans every document every time
 *
 * Both rank results by combined term frequency (TF), highest first.
 */
public class SearchEngine {

    private final InvertedIndex index;

    public SearchEngine(InvertedIndex index) {
        this.index = index;
    }

    public static class Result {
        public final Document document;
        public final int score;

        public Result(Document document, int score) {
            this.document = document;
            this.score = score;
        }
    }

    /**
     * Fast indexed search.
     * @param keywords list of query keywords
     * @param mode "AND" -> document must contain every keyword,
     *             "OR"  -> document must contain at least one keyword
     */
    public List<Result> search(List<String> keywords, String mode) {
        Map<Integer, Integer> combinedScore = new HashMap<>();
        Map<Integer, Integer> matchCount = new HashMap<>();

        for (String kw : keywords) {
            Map<Integer, Integer> postings = index.getPostings(kw);
            for (Map.Entry<Integer, Integer> e : postings.entrySet()) {
                combinedScore.merge(e.getKey(), e.getValue(), Integer::sum);
                matchCount.merge(e.getKey(), 1, Integer::sum);
            }
        }

        List<Result> results = new ArrayList<>();
        for (Map.Entry<Integer, Integer> e : combinedScore.entrySet()) {
            int docId = e.getKey();
            if ("AND".equalsIgnoreCase(mode) && matchCount.get(docId) < keywords.size()) {
                continue;
            }
            results.add(new Result(index.getDocument(docId), e.getValue()));
        }
        results.sort((a, b) -> b.score - a.score);
        return results;
    }

    /**
     * Naive baseline used only to demonstrate the speed difference:
     * re-tokenizes and scans every document for every query, with no index.
     */
    public List<Result> linearScanSearch(List<String> keywords, String mode) {
        List<Result> results = new ArrayList<>();

        for (Document doc : index.getAllDocuments()) {
            List<String> tokens = TextPreprocessor.tokenize(doc.getTitle() + " " + doc.getContent());

            int totalScore = 0;
            int matched = 0;
            for (String kw : keywords) {
                String k = kw.toLowerCase();
                int freq = 0;
                for (String t : tokens) {
                    if (t.equals(k)) freq++;
                }
                if (freq > 0) {
                    matched++;
                    totalScore += freq;
                }
            }

            if (matched == 0) continue;
            if ("AND".equalsIgnoreCase(mode) && matched < keywords.size()) continue;
            results.add(new Result(doc, totalScore));
        }

        results.sort((a, b) -> b.score - a.score);
        return results;
    }
}
