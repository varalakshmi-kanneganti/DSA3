import java.util.*;

/**
 * Core data structure of the project: a hash-based inverted index.
 *
 *   term  ->  { docId -> term frequency in that document }
 *
 * Built once over the whole corpus; every query afterwards is answered by
 * direct hash lookups instead of re-scanning every document.
 */
public class InvertedIndex {

    private final Map<String, Map<Integer, Integer>> index = new HashMap<>();
    private final Map<Integer, Document> documents = new HashMap<>();

    public void addDocument(Document doc) {
        documents.put(doc.getId(), doc);

        List<String> tokens = TextPreprocessor.tokenize(doc.getTitle() + " " + doc.getContent());
        for (String token : tokens) {
            Map<Integer, Integer> postings =
                    index.computeIfAbsent(token, k -> new HashMap<>());
            postings.merge(doc.getId(), 1, Integer::sum);
        }
    }

    public void build(List<Document> corpus) {
        for (Document d : corpus) {
            addDocument(d);
        }
    }

    /** Posting list for one term: docId -> frequency. O(1) average lookup. */
    public Map<Integer, Integer> getPostings(String term) {
        return index.getOrDefault(term.toLowerCase(), Collections.emptyMap());
    }

    public Document getDocument(int id) {
        return documents.get(id);
    }

    public Collection<Document> getAllDocuments() {
        return documents.values();
    }

    public int vocabularySize() {
        return index.size();
    }

    public int documentCount() {
        return documents.size();
    }
}
