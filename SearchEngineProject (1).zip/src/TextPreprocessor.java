import java.text.Normalizer;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles Unicode normalization, tokenization and stop-word removal
 * for both English and Indian-language (Devanagari, Telugu, Tamil,
 * Bengali, etc.) text.
 */
public class TextPreprocessor {

    // A small English stop-word list. Extend this with Hindi/Telugu/Tamil
    // stop words (e.g. "और", "के", "है", "మరియు") for a production system.
    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            "a", "an", "the", "is", "are", "was", "were", "of", "in", "on",
            "at", "to", "for", "and", "or", "but", "with", "by", "from",
            "as", "that", "this", "it", "be", "has", "have", "had", "not",
            "its", "their", "which", "also", "these", "those", "can", "will"
    ));

    // Matches a run of letters (\p{L}) plus combining marks (\p{M}) so that
    // Indian-script vowel signs / matras stay attached to their base letter.
    // UNICODE_CHARACTER_CLASS makes \p{L} work correctly across all scripts.
    private static final Pattern WORD_PATTERN =
            Pattern.compile("[\\p{L}\\p{M}]+", Pattern.UNICODE_CHARACTER_CLASS);

    /**
     * Splits text into normalized, lower-cased tokens with stop words removed.
     */
    public static List<String> tokenize(String text) {
        if (text == null || text.isEmpty()) {
            return Collections.emptyList();
        }

        // NFC normalization is important for Indian scripts: the same visible
        // character can be represented by different Unicode code-point
        // sequences (e.g. a base consonant + separate matra vs. a precomposed
        // form). Normalizing first prevents "duplicate" index entries.
        String normalized = Normalizer.normalize(text, Normalizer.Form.NFC);

        List<String> tokens = new ArrayList<>();
        Matcher m = WORD_PATTERN.matcher(normalized);
        while (m.find()) {
            String token = m.group().toLowerCase(); // no-op for non-Latin scripts
            if (token.length() < 2) continue;        // drop stray single chars
            if (STOP_WORDS.contains(token)) continue;
            tokens.add(token);
        }
        return tokens;
    }
}
